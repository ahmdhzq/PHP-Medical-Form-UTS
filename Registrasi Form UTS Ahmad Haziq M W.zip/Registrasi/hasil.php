<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Medical Form</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        .border {
            border: 1px solid;
            height: 42px;
            border-radius: 3px;
        }
    </style>
</head>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7 ">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <form action="">
                                    <div class="card-header">
                                        <h3 class="text-center font-weight-light my-4">MEDICAL FORM</h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="row mb-3">
                                            <!-- Firstname -->
                                            <div class="col-md-6 mb-3">
                                                <div class="border">
                                                    <p class="mt-2 ms-2">
                                                        <?php echo $_POST['nama'] ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- end firstname -->

                                            <!-- Lastname -->
                                            <div class="col-md-6 mb-3">
                                                <div class="border">
                                                    <p class="mt-2 ms-2">
                                                        <?php echo $_POST['lastname'] ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- endlastname -->

                                            <!-- email -->
                                            <div class="col-12 ">
                                                <div class="border">
                                                    <p class="mt-2 ms-2">
                                                        <?php echo $_POST['email'] ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- endemail -->
                                        </div>

                                        <div class="row mb-3">
                                            <!-- What is your age? -->
                                            <div class="col-md-6 mb-3">
                                                <div class="border">
                                                    <p class="mt-2 ms-2">
                                                        <?php echo $_POST['age'] ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- end what is your age? -->

                                            <!-- Gender -->
                                            <div class="col-md-6">
                                                <div class="border">
                                                    <p class="mt-2 ms-2">
                                                        <?php echo $_POST['gender'] ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- end Gender -->
                                        </div>

                                        <div class="row mb-3 d-flex align-items-center">
                                            <!-- agama -->
                                            <div class="col-md-6 mb-3">
                                                <div class="border">
                                                    <p class="mt-2 ms-2">
                                                        <?php echo $_POST['agama'] ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- end agama -->

                                            <!-- jenjang pendidikan -->
                                            <div class="col-md-6">
                                                <div class="border">
                                                    <p class="mt-2 ms-2">
                                                        <?php echo $_POST['jenjang'] ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- end jenjang pendidikan -->
                                        </div>

                                        <div class="row mb-3 d-flex align-items-center">
                                            <!-- Nama Kota -->
                                            <div class="col-md-6 mb-3">
                                                <div class="border">
                                                    <p class="mt-2 ms-2">
                                                        <?php echo $_POST['kota'] ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- end nama kota -->

                                            <!-- Provinsi -->
                                            <div class="col-md-6">
                                                <div class="border">
                                                    <p class="mt-2 ms-2">
                                                        <?php $provinsi = $_POST['prov'];
                                                        echo $provinsi; ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- end provinsi -->
                                        </div>
                                    </div>
                                    <div class="card shadow-lg border-0 rounded-lg mt-5 m-3">
                                        <div class="card-header">
                                            <h3 class="text-center font-weight-light my-4">MEDICAL CHECK FORM</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <label class="col-12">Periksa Ketentuan yang berlaku untuk Anda atau anggota kerabat dekat anda:</label>
                                                <div class="col-12">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php
                                                            if (isset($_POST['sakit1'])) {
                                                                $sakit1 = $_POST['sakit1'];
                                                                for ($i = 0; $i < count($sakit1); $i++) {
                                                                    echo $sakit1[$i] . ", ";
                                                                }
                                                            }
                                                            ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-12">Periksa gejala Anda alami saat ini:</label>
                                                <div class="col-12">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php
                                                            if (isset($_POST['sakit2'])) {
                                                                $sakit2 = $_POST['sakit2'];
                                                                for ($i = 0; $i < count($sakit2); $i++) {
                                                                    echo $sakit2[$i] . ", ";
                                                                }
                                                            }
                                                            ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-12">Apakah saat ini Anda Sedang mengonsumsi obat?</label>
                                                <div class="col-12">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['radioObat'] ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="textarea" class="col-12 col-form-label">Silakan List yang lain:</label>
                                                <div class="col-12">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['textarea'] ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mt-4 mb-0">
                                            <div class="d-grid"><a class="btn btn-primary btn-block" href="index.php">Back</a>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <div class="card-footer text-center py-3">
                                    <h4>Take care your health</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <div id="layoutAuthentication_footer">
            <footer class="py-4 bg-light mt-5">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Ahmad Haziq 2022</div>
                        <div>
                            <a href="#">Privacy Policy</a>
                            &middot;
                            <a href="#">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="js/scripts.js"></script>
</body>

</html>