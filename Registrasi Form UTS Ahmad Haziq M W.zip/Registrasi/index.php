<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Medical Form</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7 ">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <form action="hasil.php" method="POST">
                                    <div class="card-header">
                                        <h3 class="text-center font-weight-light my-4">MEDICAL FORM</h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="row mb-3">
                                            <!-- Firstname -->
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="inputFirstName" type="text" placeholder="Enter your first name" name="nama" required/>
                                                    <label for="inputFirstName">First name</label>
                                                </div>
                                            </div>
                                            <!-- end firstname -->

                                            <!-- Lastname -->
                                            <div class="col-md-6 mb-3">
                                                <div class="form-floating">
                                                    <input class="form-control" id="inputLastName" type="text" placeholder="Enter your last name" name="lastname" required/>
                                                    <label for="inputLastName">Last name</label>
                                                </div>
                                            </div>
                                            <!-- endlastname -->

                                            <!-- email -->
                                            <div class="col-12">
                                                <div class="form-floating ">
                                                    <input class="form-control" id="inputEmail" type="email" placeholder="Masukan Email" name="email" required/>
                                                    <label for="inputEmail">Email</label>
                                                </div>
                                            </div>
                                            <!-- endemail -->
                                        </div>

                                        <div class="row mb-3">
                                            <!-- What is your age? -->
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="inputAge" type="text" placeholder="how old are you" name="age" required/>
                                                    <label for="inputAge">how old are you?</label>
                                                </div>
                                            </div>
                                            <!-- end what is your age? -->

                                            <!-- Gender -->
                                            <div class="col-md-6 d-flex align-items-center">
                                                <div class="custom-control custom-radio custom-control-inline me-3">
                                                    <input name="gender" id="gender_0" type="radio" class="custom-control-input" value="Laki-laki">
                                                    <label for="gender_0" class="custom-control-label">Laki-laki</label>
                                                </div>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="gender" id="gender_1" type="radio" class="custom-control-input" value="Perempuan">
                                                    <label for="gender_1" class="custom-control-label">Perempuan</label>
                                                </div>
                                            </div>
                                            <!-- end Gender -->
                                        </div>

                                        <div class="row mb-3 d-flex align-items-center">
                                            <!-- agama -->
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <select id="agama" name="agama" required class="custom-select">
                                                        <option value="">Agama</option>
                                                        <option value="Islam">Islam</option>
                                                        <option value="Kristen">Kristen</option>
                                                        <option value="Budha">Budha</option>
                                                        <option value="Hindu">Hindu</option>
                                                        <option value="Katolik">Katolik</option>
                                                        <option value="Konghucu">Konghucu</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <!-- end agama -->

                                            <!-- jenjang pendidikan -->
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <select id="jenjang" name="jenjang" required class="custom-select">
                                                        <option value="">Jenjang Pendidikan</option>
                                                        <option value="SD">SD</option>
                                                        <option value="SMP">SMP</option>
                                                        <option value="SMA">SMA</option>
                                                        <option value="DI">DI</option>
                                                        <option value="DII">DII</option>
                                                        <option value="DIII">DIII</option>
                                                        <option value="S1">S1</option>
                                                        <option value="S2">S2</option>
                                                        <option value="S3">S3</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <!-- end jenjang pendidikan -->
                                        </div>

                                        <div class="row mb-3 d-flex align-items-center">
                                            <!-- Nama Kota -->
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="inputKota" type="text" placeholder="Masukan Nama Kota" name="kota" required/>
                                                    <label for="inputKota">Nama Kota</label>
                                                </div>
                                            </div>
                                            <!-- end nama kota -->

                                            <!-- Provinsi -->
                                            <?php
                                            $provinsi = [
                                                "Nanggroe Aceh Darussalam" => "Nanggroe Aceh Darussalam",
                                                "Sumatera Utara" => "Sumatera Utara",
                                                "Sumatera Selatan" => "Sumatera Selatan",
                                                "Sumatera Barat" => "Sumatera Barat",
                                                "Bengkulu" => "Bengkulu",
                                                "Riau" => "Riau",
                                                "Kepulauan Riau" => "Kepulauan Riau",
                                                "Jambi" => "Jambi",
                                                "Lampung" => "Lampung",
                                                "Bangka Belitung" => "Bangka Belitung",
                                                "Kalimantan Barat" => "Kalimantan Barat",
                                                "Kalimantan Timur" => "Kalimantan Timur",
                                                "Kalimantan Selatan" => "Kalimantan Selatan",
                                                "Kalimantan Tengah" => "Kalimantan Tengah",
                                                "Kalimantan Utara" => "Kalimantan Utara",
                                                "Banten" => "Banten",
                                                "DKI Jakarta" => "DKI Jakarta",
                                                "Daerah Istimewa Yogyakarta" => "Daerah Istimewa Yogyakarta",
                                                "Jawa Barat" => "Jawa Barat",
                                                "Jawa Tengah" => "Jawa Tengah",
                                                "Jawa Timur" => "Jawa Timur",
                                                "Bali" => "Bali",
                                                "Nusa Tenggara Timur" => "Nusa Tenggara Timur",
                                                "Nusa Tenggara Barat" => "Nusa Tenggara Barat",
                                                "Gorontalo" => "Gorontalo",
                                                "Sulawesi Barat" => "Sulawesi Barat",
                                                "Sulawesi Tengah" => "Sulawesi Tengah",
                                                "Sulawesi Utara" => "Sulawesi Utara",
                                                "Sulawesi Tenggara" => "Sulawesi Tenggara",
                                                "Sulawesi Selatan" => "Sulawesi Selatan",
                                                "Maluku Utara" => "Maluku Utara",
                                                "Maluku" => "Maluku",
                                                "Papua Barat" => "Papua Barat",
                                                "Papua" => "Papua",
                                                "Papua Tengah" => "Papua Tengah",
                                                "Papua Pegunungan" => "Papua Pegunungan",
                                                "Papua Selatan" => "Papua Selatan",
                                                "Papua Barat Daya" => "Papua Barat Daya"
                                            ];
                                            ?>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <select id="select" name="prov" required class="custom-select">
                                                        <?php
                                                        foreach ($provinsi as $key => $val) {
                                                            echo '<option value="' . $val . '">' . $key . '</option>';
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <!-- end provinsi -->
                                        </div>
                                    </div>
                                    <div class="card shadow-lg border-0 rounded-lg mt-5 m-3">
                                        <div class="card-header">
                                            <h3 class="text-center font-weight-light my-4">MEDICAL CHECK FORM</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <label class="col-12">Periksa Ketentuan yang berlaku untuk Anda atau anggota kerabat dekat anda:</label>
                                                <div class="col-12">
                                                    <div class="custom-control custom-checkbox custom-control-inline">
                                                        <input name="sakit1[]" id="sakit1_0" type="checkbox" class="custom-control-input" value="Asma">
                                                        <label for="sakit1_0" class="custom-control-label">Asma</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox custom-control-inline">
                                                        <input name="sakit1[]" id="sakit1_1" type="checkbox" class="custom-control-input" value="Penyakit Jantung">
                                                        <label for="sakit1_1" class="custom-control-label">Penyakit Jantung</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox custom-control-inline">
                                                        <input name="sakit1[]" id="sakit1_2" type="checkbox" class="custom-control-input" value="Kanker">
                                                        <label for="sakit1_2" class="custom-control-label">Kanker</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox custom-control-inline">
                                                        <input name="sakit1[]" id="sakit1_3" type="checkbox" class="custom-control-input" value="Diabetes">
                                                        <label for="sakit1_3" class="custom-control-label">Diabetes</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-12">Periksa gejala Anda alami saat ini:</label>
                                                <div class="col-12">
                                                    <div class="custom-control custom-checkbox custom-control-inline">
                                                        <input name="sakit2[]" id="sakit2_0" type="checkbox" class="custom-control-input" value="Sakit Dada">
                                                        <label for="sakit2_0" class="custom-control-label">Sakit Dada</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox custom-control-inline">
                                                        <input name="sakit2[]" id="sakit2_1" type="checkbox" class="custom-control-input" value="Kardiovaskular">
                                                        <label for="sakit2_1" class="custom-control-label">kardiovaskular</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox custom-control-inline">
                                                        <input name="sakit2[]" id="sakit2_2" type="checkbox" class="custom-control-input" value="Pernafasan">
                                                        <label for="sakit2_2" class="custom-control-label">Pernafasan</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox custom-control-inline">
                                                        <input name="sakit2[]" id="sakit2_3" type="checkbox" class="custom-control-input" value="Penambahan BB">
                                                        <label for="sakit2_3" class="custom-control-label">Penambahan BB</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-12">Apakah saat ini Anda Sedang mengonsumsi obat?</label>
                                                <div class="col-12">
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input name="radioObat" id="radioObat_0" type="radio" class="custom-control-input" value="Ya">
                                                        <label for="radioObat_0" class="custom-control-label">Ya</label>
                                                    </div>
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input name="radioObat" id="radioObat_1" type="radio" class="custom-control-input" value="Tidak">
                                                        <label for="radioObat_1" class="custom-control-label">Tidak</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="textarea" class="col-12 col-form-label">Silakan List yang lain:</label>
                                                <div class="col-12">
                                                    <textarea id="textarea" name="textarea" cols="40" rows="5" class="form-control"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mt-4 mb-0">
                                            <div class="d-grid">
                                                <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <div class="card-footer text-center py-3">
                                    <h4>Take care your health</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <div id="layoutAuthentication_footer">
            <footer class="py-4 bg-light mt-5">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Ahmad Haziq 2022</div>
                        <div>
                            <a href="#">Privacy Policy</a>
                            &middot;
                            <a href="#">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="js/scripts.js"></script>
</body>

</html>